package com.fqz.bluetoothterminal.ui.devices

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.databinding.ItemDeviceBinding

class DeviceAdapter(
    private val onClick: (DeviceItem) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.VH>() {
    private val items = mutableListOf<DeviceItem>()

    fun submit(list: List<DeviceItem>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position], onClick)
    }

    override fun getItemCount(): Int = items.size

    class VH(private val binding: ItemDeviceBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: DeviceItem, onClick: (DeviceItem) -> Unit) {
            binding.name.text = item.name
            binding.address.text = item.address

            binding.chip.text = if (item.bonded) {
                binding.root.context.getString(R.string.label_paired)
            } else {
                binding.root.context.getString(R.string.label_nearby)
            }

            val chipColor = if (item.bonded) {
                ContextCompat.getColor(binding.root.context, R.color.bt_state_ok)
            } else {
                ContextCompat.getColor(binding.root.context, R.color.bt_state_warn)
            }
            binding.chip.chipBackgroundColor =
                ContextCompat.getColorStateList(binding.root.context, android.R.color.transparent)
            binding.chip.chipStrokeColor = ColorStateList.valueOf(chipColor)
            binding.chip.chipStrokeWidth = 1f * binding.root.resources.displayMetrics.density
            binding.chip.setTextColor(chipColor)

            binding.root.setOnClickListener { onClick(item) }
        }
    }
}

