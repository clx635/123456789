package com.fqz.bluetoothterminal.ui.ai

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.bluetooth.BtActions
import com.fqz.bluetoothterminal.bluetooth.BtPrefs
import com.fqz.bluetoothterminal.bluetooth.BtState
import com.fqz.bluetoothterminal.bluetooth.BluetoothSerialService
import com.fqz.bluetoothterminal.databinding.ActivityAiBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONObject

class AiActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAiBinding
    private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private var service: BluetoothSerialService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as? BluetoothSerialService.LocalBinder ?: return
            service = b.getService()
            serviceBound = true
            val svc = service ?: return
            val s = svc.getState()
            val devName = svc.getConnectedDeviceName() ?: BtPrefs.getLastDeviceName(this@AiActivity)
            val devAddr = svc.getConnectedDeviceAddress() ?: BtPrefs.getLastDeviceAddress(this@AiActivity)
            updateStateUi(s, devName, devAddr)
            if (s == BtState.CONNECTED) {
                svc.startAiHealthAnalysis()
                svc.requestAiSummaryNow()
            } else {
                binding.tvAiLog.append("未连接蓝牙设备，无法开始AI分析。请先在“通信”页连接并接收数据。\n\n")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            service = null
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BtActions.ACTION_STATE -> {
                    val s = intent.getIntExtra(BtActions.EXTRA_STATE, BtState.DISCONNECTED)
                    val name = intent.getStringExtra(BtActions.EXTRA_DEVICE_NAME)
                    val addr = intent.getStringExtra(BtActions.EXTRA_DEVICE_ADDRESS)
                    updateStateUi(s, name, addr)
                }
                BtActions.ACTION_AI -> {
                    val type = intent.getStringExtra(BtActions.EXTRA_TYPE).orEmpty()
                    val text = intent.getStringExtra(BtActions.EXTRA_TEXT).orEmpty()
                    if (text.isNotBlank()) handleAi(type, text)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnClear.setOnClickListener {
            binding.tvAiLog.text = ""
            binding.tvRisk.text = "RISK: —"
        }

        registerReceivers()
        bindService(Intent(this, BluetoothSerialService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)

        val lastName = BtPrefs.getLastDeviceName(this)
        val lastAddr = BtPrefs.getLastDeviceAddress(this)
        binding.tvDevice.text = formatDevice(lastName, lastAddr)
        updateStateUi(BtState.DISCONNECTED, lastName, lastAddr)
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(receiver) }
        if (serviceBound) {
            runCatching { service?.stopAiHealthAnalysis() }
            runCatching { unbindService(serviceConnection) }
            serviceBound = false
            service = null
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(BtActions.ACTION_STATE)
            addAction(BtActions.ACTION_AI)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun updateStateUi(state: Int, name: String?, address: String?) {
        binding.tvDevice.text = formatDevice(name, address)
        binding.tvState.text = when (state) {
            BtState.CONNECTING -> getString(R.string.label_connecting)
            BtState.CONNECTED -> getString(R.string.label_connected)
            else -> getString(R.string.label_not_connected)
        }
    }

    private fun handleAi(type: String, text: String) {
        val pretty = runCatching { JSONObject(text).toString(2) }.getOrDefault(text)
        val now = sdf.format(Date())
        val line = "[$now][AI:$type]\n$pretty\n\n"
        binding.tvAiLog.append(line)
        binding.aiScroll.post { binding.aiScroll.fullScroll(android.view.View.FOCUS_DOWN) }

        if (type == "rule") {
            val risk = runCatching { JSONObject(text).optString("risk", "") }.getOrDefault("")
            if (risk.isNotBlank()) {
                binding.tvRisk.text = "RISK: $risk"
            }
        }
    }

    private fun formatDevice(name: String?, address: String?): String {
        val n = name?.takeIf { it.isNotBlank() } ?: "Unknown"
        val a = address?.takeIf { it.isNotBlank() } ?: "—"
        return "$n ($a)"
    }
}
