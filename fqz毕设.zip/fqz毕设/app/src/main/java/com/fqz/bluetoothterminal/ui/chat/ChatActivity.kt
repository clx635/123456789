package com.fqz.bluetoothterminal.ui.chat

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.method.ScrollingMovementMethod
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.bluetooth.BtActions
import com.fqz.bluetoothterminal.bluetooth.BtPrefs
import com.fqz.bluetoothterminal.bluetooth.BtState
import com.fqz.bluetoothterminal.bluetooth.BluetoothSerialService
import com.fqz.bluetoothterminal.databinding.ActivityChatBinding
import com.fqz.bluetoothterminal.settings.AppSettings
import com.fqz.bluetoothterminal.ui.ai.AiActivity
import com.fqz.bluetoothterminal.ui.devices.DeviceListActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding
    private val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val rxLineBuffer = StringBuilder()

    private var service: BluetoothSerialService? = null
    private var serviceBound = false
    private val stateSyncHandler = Handler(Looper.getMainLooper())
    private var stateSyncDeadlineMs: Long = 0L
    private val stateSyncRunnable = object : Runnable {
        override fun run() {
            if (serviceBound) {
                val s = syncFromService() ?: return
                val now = SystemClock.uptimeMillis()
                if (s == BtState.CONNECTING && now < stateSyncDeadlineMs) {
                    stateSyncHandler.postDelayed(this, 300L)
                }
            }
        }
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as? BluetoothSerialService.LocalBinder ?: return
            service = b.getService()
            serviceBound = true
            val s = syncFromService() ?: return
            if (s == BtState.CONNECTING) {
                startStateSync(12_000L)
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            service = null
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BtActions.ACTION_STATE -> {
                    val s = intent.getIntExtra(BtActions.EXTRA_STATE, BtState.DISCONNECTED)
                    val name = intent.getStringExtra(BtActions.EXTRA_DEVICE_NAME)
                    val addr = intent.getStringExtra(BtActions.EXTRA_DEVICE_ADDRESS)
                    updateStateUi(s, name, addr)
                }
                BtActions.ACTION_RX -> {
                    val text = intent.getStringExtra(BtActions.EXTRA_TEXT).orEmpty()
                    if (text.isNotEmpty()) handleRx(text)
                }
                BtActions.ACTION_LOG -> {
                    val text = intent.getStringExtra(BtActions.EXTRA_TEXT).orEmpty()
                    if (text.isNotEmpty()) appendLog("SYS", text)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.tvLog.movementMethod = ScrollingMovementMethod()
        setupLogScrollTouch()

        binding.btnSend.setOnClickListener { sendNow() }
        binding.btnConnect.setOnClickListener { connectOrDisconnect() }
        binding.btnAiAnalyze.setOnClickListener { startActivity(Intent(this, AiActivity::class.java)) }

        bindService(Intent(this, BluetoothSerialService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
        registerReceivers()

        val lastName = BtPrefs.getLastDeviceName(this)
        val lastAddr = BtPrefs.getLastDeviceAddress(this)
        binding.tvDevice.text = formatDevice(lastName, lastAddr)
        updateStateUi(BtState.DISCONNECTED, lastName, lastAddr)
    }

    override fun onStart() {
        super.onStart()
        val s = syncFromService()
        if (s == BtState.CONNECTING) {
            startStateSync(12_000L)
        }
    }

    override fun onStop() {
        super.onStop()
        stateSyncHandler.removeCallbacks(stateSyncRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(receiver) }
        if (serviceBound) {
            unbindService(serviceConnection)
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply {
            addAction(BtActions.ACTION_STATE)
            addAction(BtActions.ACTION_RX)
            addAction(BtActions.ACTION_LOG)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun syncFromService(): Int? {
        val svc = service ?: return
        val s = svc.getState()
        updateStateUi(s, svc.getConnectedDeviceName(), svc.getConnectedDeviceAddress())
        return s
    }

    private fun startStateSync(durationMs: Long) {
        stateSyncDeadlineMs = SystemClock.uptimeMillis() + durationMs
        stateSyncHandler.removeCallbacks(stateSyncRunnable)
        stateSyncHandler.post(stateSyncRunnable)
    }

    private fun connectOrDisconnect() {
        val svc = service ?: return
        if (svc.getState() == BtState.CONNECTED || svc.getState() == BtState.CONNECTING) {
            svc.disconnect(true)
            startStateSync(6_000L)
            return
        }
        val lastAddr = BtPrefs.getLastDeviceAddress(this)
        if (lastAddr.isNullOrBlank()) {
            startActivity(Intent(this, DeviceListActivity::class.java))
            return
        }
        svc.connect(lastAddr)
        startStateSync(12_000L)
    }

    private fun sendNow() {
        val text = binding.etMessage.text?.toString().orEmpty()
        if (text.isBlank()) return
        val ok = service?.send(text) == true
        if (ok) {
            appendLog("TX", text)
            binding.etMessage.setText("")
        } else {
            appendLog("SYS", "未连接，无法发送")
        }
    }

    private fun updateStateUi(state: Int, name: String?, address: String?) {
        binding.tvDevice.text = formatDevice(name, address)
        when (state) {
            BtState.CONNECTING -> {
                binding.tvState.text = getString(R.string.label_connecting)
                binding.btnConnect.text = getString(R.string.action_disconnect)
            }
            BtState.CONNECTED -> {
                binding.tvState.text = getString(R.string.label_connected)
                binding.btnConnect.text = getString(R.string.action_disconnect)
            }
            else -> {
                binding.tvState.text = getString(R.string.label_not_connected)
                binding.btnConnect.text = getString(R.string.action_connect)
            }
        }
    }

    private fun appendLog(tag: String, text: String, time: String? = null) {
        val t = time ?: sdf.format(Date())
        val line = "[$t][$tag] $text\n"
        binding.tvLog.append(line)
        if (autoScroll) {
            binding.logScroll.post { binding.logScroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }

    private fun handleRx(chunk: String) {
        rxLineBuffer.append(chunk)
        while (true) {
            val idxN = rxLineBuffer.indexOf("\n")
            val idxR = rxLineBuffer.indexOf("\r")
            val idx = when {
                idxN >= 0 && idxR >= 0 -> minOf(idxN, idxR)
                idxN >= 0 -> idxN
                else -> idxR
            }
            if (idx < 0) break

            val rawLine = rxLineBuffer.substring(0, idx)
            val delimiter = rxLineBuffer.getOrNull(idx)
            val skip = if (delimiter == '\r' && rxLineBuffer.getOrNull(idx + 1) == '\n') 2 else 1
            rxLineBuffer.delete(0, idx + skip)

            val line = rawLine.trim()
            if (line.isEmpty()) continue
            val time = sdf.format(Date())
            appendLog("RX", line, time)
            if (AppSettings.isParseEnabled(this)) {
                appendLog("解析", parseLine(line), time)
            }
        }

        if (rxLineBuffer.length >= 256) {
            val line = rxLineBuffer.toString().trim()
            rxLineBuffer.clear()
            if (line.isNotEmpty()) {
                val time = sdf.format(Date())
                appendLog("RX", line, time)
                if (AppSettings.isParseEnabled(this)) {
                    appendLog("解析", parseLine(line), time)
                }
            }
        }
    }

    private fun parseLine(rawLine: String): String {
        val line = rawLine.trim()
        if (line.isEmpty()) return ""

        parseHexBytes(line)?.let { bytes ->
            val hex = bytes.joinToString(" ") { b -> String.format(Locale.US, "%02X", b) }
            val ascii = buildString(bytes.size) {
                bytes.forEach { b ->
                    val c = b.toInt() and 0xFF
                    append(if (c in 32..126) c.toChar() else '.')
                }
            }
            return "HEX(${bytes.size}): $hex | ASCII: $ascii"
        }

        val sep = when {
            line.contains("==") -> "=="
            line.contains("=") -> "="
            line.contains(":") -> ":"
            else -> null
        }
        if (sep != null) {
            val parts = line.split(sep, limit = 2)
            val k = parts.getOrNull(0).orEmpty().trim()
            val v = parts.getOrNull(1).orEmpty().trim()
            if (k.isNotEmpty() && v.isNotEmpty()) {
                return "$k $sep $v"
            }
        }

        if (line.contains(",")) {
            val items = line.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (items.size >= 2) {
                return "列表(${items.size}): ${items.joinToString(" | ")}"
            }
        }

        return "文本(${line.length}): $line"
    }

    private fun parseHexBytes(s: String): ByteArray? {
        val tokens = s
            .replace(",", " ")
            .replace(";", " ")
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

        fun tokenToByte(t: String): Byte? {
            val x = t.removePrefix("0x").removePrefix("0X")
            if (x.length != 2) return null
            if (!x.matches(Regex("(?i)^[0-9a-f]{2}$"))) return null
            return x.toInt(16).toByte()
        }

        if (tokens.size >= 2) {
            val bytes = tokens.mapNotNull { tokenToByte(it) }
            if (bytes.size == tokens.size) return bytes.toByteArray()
        }

        val hexOnly = s
            .replace(Regex("(?i)0x"), "")
            .replace(Regex("[,\\s;]"), "")
            .trim()
        if (hexOnly.length >= 4 && hexOnly.length % 2 == 0 && hexOnly.matches(Regex("(?i)^[0-9a-f]+$"))) {
            val bytes = ByteArray(hexOnly.length / 2)
            var i = 0
            while (i < hexOnly.length) {
                val b = hexOnly.substring(i, i + 2).toInt(16).toByte()
                bytes[i / 2] = b
                i += 2
            }
            return bytes
        }

        return null
    }

    private var autoScroll = true

    private fun setupLogScrollTouch() {
        binding.logScroll.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        binding.logScroll.viewTreeObserver.addOnScrollChangedListener {
            val content = binding.logScroll.getChildAt(0) ?: return@addOnScrollChangedListener
            val diff = content.bottom - (binding.logScroll.height + binding.logScroll.scrollY)
            autoScroll = diff <= (12 * resources.displayMetrics.density).toInt()
        }
    }

    private fun formatDevice(name: String?, address: String?): String {
        val n = name?.takeIf { it.isNotBlank() } ?: "Unknown"
        val a = address?.takeIf { it.isNotBlank() } ?: "—"
        return "$n ($a)"
    }
}

