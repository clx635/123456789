package com.fqz.bluetoothterminal.bluetooth

import android.Manifest
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.fqz.bluetoothterminal.settings.AppSettings
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import org.json.JSONArray
import org.json.JSONObject

class BluetoothSerialService : Service() {
    private val binder = LocalBinder()
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val state = AtomicInteger(BtState.DISCONNECTED)
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var deviceName: String? = null
    private var deviceAddress: String? = null
    private var manualDisconnect = false

    private val maxReconnectAttempts = 5
    private var reconnectAttempts = 0
    private var reconnectRunnable: Runnable? = null
    private val reconnectGeneration = AtomicInteger(0)

    private data class VitalSample(
        val tsMs: Long,
        val hr: Int,
        val spo2: Int,
        val tempC: Double
    )

    private val vitalLock = Any()
    private val vitalRxLineBuffer = StringBuilder()
    private val vitalSamples = ArrayList<VitalSample>(128)
    private var lastAiSummaryTsMs: Long = 0L
    private var aiSummaryRunnable: Runnable? = null
    private val aiIntervalMs = 5 * 60 * 1000L
    private var aiAnalysisActive = false
    private var aiAnalysisStartTsMs: Long = 0L

    private val btStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != BluetoothAdapter.ACTION_STATE_CHANGED) return
            val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
            if (s == BluetoothAdapter.STATE_ON) {
                maybeScheduleReconnect(0L)
            }
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothSerialService = this@BluetoothSerialService
    }

    override fun onCreate() {
        super.onCreate()
        runCatching {
            registerReceiver(btStateReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
        }
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    fun getState(): Int = state.get()

    fun getConnectedDeviceName(): String? = deviceName

    fun getConnectedDeviceAddress(): String? = deviceAddress

    fun connect(address: String): Boolean {
        cancelReconnect(resetAttempts = false)
        val adapter = bluetoothAdapter ?: run {
            sendLog(getStringLabel("label_bluetooth_unsupported"))
            setState(BtState.DISCONNECTED, null, null)
            return false
        }
        val device = runCatching { adapter.getRemoteDevice(address) }.getOrNull() ?: return false
        if (!state.compareAndSet(BtState.DISCONNECTED, BtState.CONNECTING)) {
            return false
        }
        manualDisconnect = false
        deviceName = getSafeDeviceName(device)
        deviceAddress = getSafeDeviceAddress(device)
        setState(BtState.CONNECTING, deviceName, deviceAddress)
        ioExecutor.execute {
            try {
                try {
                    if (hasScanPermission()) {
                        adapter.cancelDiscovery()
                    }
                } catch (_: SecurityException) {
                }
                closeSocket()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) {
                    throw SecurityException("Missing BLUETOOTH_CONNECT")
                }
                val s = connectWithFallback(device)
                socket = s
                inputStream = s.inputStream
                outputStream = s.outputStream
                BtPrefs.setLastDevice(this, deviceName, deviceAddress)
                reconnectAttempts = 0
                setState(BtState.CONNECTED, deviceName, deviceAddress)
                startReadLoop()
            } catch (e: Exception) {
                closeSocket()
                setState(BtState.DISCONNECTED, deviceName, deviceAddress)
                sendLog("连接失败: ${e.message ?: e.javaClass.simpleName}")
                maybeScheduleReconnect()
            }
        }
        return true
    }

    fun disconnect(manual: Boolean) {
        manualDisconnect = manual
        if (manual) {
            cancelReconnect(resetAttempts = true)
        }
        stopAiHealthAnalysis()
        ioExecutor.execute {
            closeSocket()
            setState(BtState.DISCONNECTED, deviceName, deviceAddress)
            if (!manualDisconnect) {
                maybeScheduleReconnect()
            }
        }
    }

    fun send(text: String): Boolean {
        if (state.get() != BtState.CONNECTED) {
            return false
        }
        val out = outputStream ?: return false
        val txCharset = AppSettings.getTxCharset(this)
        val payload = applyLineEnding(text, AppSettings.getLineEnding(this))
        return runCatching {
            out.write(payload.toByteArray(txCharset))
            out.flush()
        }.onFailure {
            sendLog("发送失败: ${it.message ?: it.javaClass.simpleName}")
            disconnect(false)
        }.isSuccess
    }

    private fun applyLineEnding(text: String, lineEnding: String): String {
        return when (lineEnding) {
            AppSettings.LINE_ENDING_LF -> text + "\n"
            AppSettings.LINE_ENDING_CRLF -> text + "\r\n"
            else -> text
        }
    }

    private fun createSocket(device: BluetoothDevice): BluetoothSocket {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            throw SecurityException("Missing BLUETOOTH_CONNECT")
        }
        return device.createRfcommSocketToServiceRecord(sppUuid)
    }

    private fun connectWithFallback(device: BluetoothDevice): BluetoothSocket {
        val candidates = ArrayList<BluetoothSocket>(3)

        val isBonded = runCatching { device.bondState == BluetoothDevice.BOND_BONDED }.getOrDefault(false)

        fun addInsecure() {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) {
                    throw SecurityException("Missing BLUETOOTH_CONNECT")
                }
                candidates.add(device.createInsecureRfcommSocketToServiceRecord(sppUuid))
            }
        }

        fun addSecure() {
            candidates.add(createSocket(device))
        }

        if (isBonded) {
            addSecure()
            addInsecure()
        } else {
            addInsecure()
            addSecure()
        }

        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                throw SecurityException("Missing BLUETOOTH_CONNECT")
            }
            val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
            val s = m.invoke(device, 1) as? BluetoothSocket
            if (s != null) candidates.add(s)
        }

        var lastError: Exception? = null
        for ((idx, s) in candidates.withIndex()) {
            try {
                s.connect()
                if (idx > 0) {
                    sendLog("已切换兼容连接方式(${idx + 1}/${candidates.size})")
                }
                return s
            } catch (e: Exception) {
                lastError = e
                runCatching { s.close() }
            }
        }
        throw lastError ?: IllegalStateException("No socket candidates")
    }

    private fun startReadLoop() {
        val input = inputStream ?: return
        val rxCharsetProvider: () -> Charset = { AppSettings.getRxCharset(this) }
        val buffer = ByteArray(1024)
        while (state.get() == BtState.CONNECTED && socket?.isConnected == true) {
            val len = runCatching { input.read(buffer) }.getOrElse { -1 }
            if (len <= 0) {
                break
            }
            val text = runCatching { String(buffer, 0, len, rxCharsetProvider()) }.getOrDefault("")
            if (text.isNotEmpty()) {
                handleVitalRxChunk(text)
                sendRx(text)
            }
        }
        if (!manualDisconnect) {
            SystemClock.sleep(100)
            disconnect(false)
        }
    }

    private fun handleVitalRxChunk(chunk: String) {
        vitalRxLineBuffer.append(chunk)
        while (true) {
            val idxN = vitalRxLineBuffer.indexOf("\n")
            val idxR = vitalRxLineBuffer.indexOf("\r")
            val idx = when {
                idxN >= 0 && idxR >= 0 -> minOf(idxN, idxR)
                idxN >= 0 -> idxN
                else -> idxR
            }
            if (idx < 0) break

            val rawLine = vitalRxLineBuffer.substring(0, idx)
            val delimiter = vitalRxLineBuffer.getOrNull(idx)
            val skip = if (delimiter == '\r' && vitalRxLineBuffer.getOrNull(idx + 1) == '\n') 2 else 1
            vitalRxLineBuffer.delete(0, idx + skip)

            val line = rawLine.trim()
            if (line.isNotEmpty()) {
                onVitalLine(line, System.currentTimeMillis())
            }
        }

        if (vitalRxLineBuffer.length >= 1024) {
            val line = vitalRxLineBuffer.toString().trim()
            vitalRxLineBuffer.clear()
            if (line.isNotEmpty()) {
                onVitalLine(line, System.currentTimeMillis())
            }
        }
    }

    private fun onVitalLine(line: String, tsMs: Long) {
        val sample = parseVitalSample(line, tsMs) ?: return
        val rule = evaluateRule(sample)
        recordSample(sample)
        sendAi("rule", buildRuleJson(sample, rule.first, rule.second).toString())
    }

    private fun parseVitalSample(line: String, tsMs: Long): VitalSample? {
        var hr: Int? = null
        var spo2: Int? = null
        var tempC: Double? = null

        val parts = line.split(",")
        for (p in parts) {
            val kv = p.split("=", limit = 2)
            if (kv.size != 2) continue
            val k = kv[0].trim().uppercase(Locale.US)
            val v = kv[1].trim()
            when (k) {
                "HR", "HEART", "HEARTRATE" -> hr = v.toIntOrNull()
                "SPO2", "SP02", "O2" -> spo2 = v.toIntOrNull()
                "T", "TEMP", "TEMPC" -> tempC = v.toDoubleOrNull()
            }
        }

        val h = hr ?: return null
        val s = spo2 ?: return null
        val t = tempC ?: return null

        if (h !in 20..250) return null
        if (s !in 50..100) return null
        if (t < 30.0 || t > 45.0) return null

        return VitalSample(tsMs = tsMs, hr = h, spo2 = s, tempC = t)
    }

    private fun evaluateRule(sample: VitalSample): Pair<String, List<String>> {
        var risk = 0
        val reasons = ArrayList<String>(3)

        fun bump(level: Int, reason: String) {
            if (level > risk) risk = level
            reasons.add(reason)
        }

        when {
            sample.spo2 < 90 -> bump(2, "血氧偏低(${sample.spo2}%)")
            sample.spo2 < 94 -> bump(1, "血氧略低(${sample.spo2}%)")
        }
        when {
            sample.tempC >= 38.0 -> bump(2, "体温偏高(${String.format(Locale.US, "%.1f", sample.tempC)}℃)")
            sample.tempC >= 37.3 -> bump(1, "体温略高(${String.format(Locale.US, "%.1f", sample.tempC)}℃)")
        }
        when {
            sample.hr < 45 -> bump(2, "心率偏低(${sample.hr})")
            sample.hr < 55 -> bump(1, "心率略低(${sample.hr})")
            sample.hr > 120 -> bump(2, "心率偏高(${sample.hr})")
            sample.hr > 100 -> bump(1, "心率略高(${sample.hr})")
        }

        val label = when (risk) {
            2 -> "ALERT"
            1 -> "WARN"
            else -> "NORMAL"
        }
        return label to reasons.distinct()
    }

    private fun recordSample(sample: VitalSample) {
        synchronized(vitalLock) {
            vitalSamples.add(sample)
            val cutoff = System.currentTimeMillis() - 60 * 60 * 1000L
            var removeCount = 0
            for (i in vitalSamples.indices) {
                if (vitalSamples[i].tsMs >= cutoff) break
                removeCount++
            }
            if (removeCount > 0) {
                vitalSamples.subList(0, removeCount).clear()
            }
        }
    }

    private fun buildRuleJson(sample: VitalSample, risk: String, reasons: List<String>): JSONObject {
        val obj = JSONObject()
        obj.put("type", "rule")
        obj.put("ts_ms", sample.tsMs)
        obj.put("hr", sample.hr)
        obj.put("spo2", sample.spo2)
        obj.put("temp_c", sample.tempC)
        obj.put("risk", risk)
        val arr = JSONArray()
        reasons.forEach { arr.put(it) }
        obj.put("reasons", arr)
        return obj
    }

    fun startAiHealthAnalysis() {
        mainHandler.post {
            stopAiHealthAnalysis()
            aiAnalysisActive = true
            aiAnalysisStartTsMs = 0L
        }
    }

    fun stopAiHealthAnalysis() {
        aiAnalysisActive = false
        aiAnalysisStartTsMs = 0L
        aiSummaryRunnable?.let { mainHandler.removeCallbacks(it) }
        aiSummaryRunnable = null
    }

    fun requestAiSummaryNow() {
        mainHandler.post { triggerAiSummary(windowMs = 30 * 60 * 1000L) }
    }

    private fun triggerAiSummary(windowMs: Long) {
        if (!aiAnalysisActive) return
        if (state.get() != BtState.CONNECTED) {
            val obj = JSONObject()
            obj.put("type", "info")
            obj.put("message", "蓝牙未连接，无法进行AI分析")
            sendAi("info", obj.toString())
            return
        }
        val end = System.currentTimeMillis()
        val baseStart = end - windowMs
        val start = maxOf(baseStart, aiAnalysisStartTsMs)
        val window = synchronized(vitalLock) { vitalSamples.filter { it.tsMs in start..end } }
        if (window.isEmpty()) {
            lastAiSummaryTsMs = end
            val minutes = (windowMs / 60000L).coerceAtLeast(1)
            val obj = JSONObject()
            obj.put("type", "info")
            obj.put("message", "最近${minutes}分钟没有可用的心率/血氧/体温数据日志")
            sendAi("info", obj.toString())
            return
        }
        lastAiSummaryTsMs = end

        analysisExecutor.execute {
            val endpoint = AppSettings.getAiEndpoint(this)
            val enabled = AppSettings.isAiEnabled(this)
            val apiKey = AppSettings.getAiApiKey(this)
            val model = AppSettings.getAiModel(this)
            val json = if (enabled && endpoint.isNotBlank()) {
                runCatching { callAiEndpoint(endpoint, apiKey, model, window, start, end) }
                    .getOrElse { buildLocalSummary(window, start, end, provider = "fallback") }
            } else {
                buildLocalSummary(window, start, end, provider = "local")
            }
            sendAi("summary", json.toString())
        }
    }

    private fun callAiEndpoint(
        endpoint: String,
        apiKey: String,
        model: String,
        window: List<VitalSample>,
        start: Long,
        end: Long
    ): JSONObject {
        if (isOpenAiChatCompletionsEndpoint(endpoint) && apiKey.isNotBlank() && model.isNotBlank()) {
            return callOpenAiChatCompletions(endpoint, apiKey, model, window, start, end)
        }

        val payload = JSONObject()
        payload.put("type", "vitals_summary")
        payload.put("from_ts_ms", start)
        payload.put("to_ts_ms", end)
        val samples = JSONArray()
        downsample(window).forEach { s ->
            val o = JSONObject()
            o.put("ts_ms", s.tsMs)
            o.put("hr", s.hr)
            o.put("spo2", s.spo2)
            o.put("temp_c", s.tempC)
            samples.put(o)
        }
        payload.put("samples", samples)

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 15000
            doInput = true
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        conn.outputStream.use { os ->
            val bytes = payload.toString().toByteArray(Charsets.UTF_8)
            os.write(bytes)
        }
        val code = conn.responseCode
        val body = runCatching {
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        }.getOrDefault("")
        if (body.isBlank()) {
            throw IllegalStateException("Empty response($code)")
        }
        return runCatching { JSONObject(body) }.getOrElse {
            JSONObject().put("type", "summary").put("provider", "endpoint").put("raw", body)
        }
    }

    private fun isOpenAiChatCompletionsEndpoint(endpoint: String): Boolean {
        val e = endpoint.trim().lowercase(Locale.US)
        return e.contains("/v1/chat/completions") || e.endsWith("/chat/completions")
    }

    private fun callOpenAiChatCompletions(
        endpoint: String,
        apiKey: String,
        model: String,
        window: List<VitalSample>,
        start: Long,
        end: Long
    ): JSONObject {
        val stats = buildWindowStats(window, start, end)
        val systemPrompt = """
            你是健康数据分析助手。你只输出一个JSON对象，不要输出任何Markdown或多余文本。
            输出字段建议包含：
            type(固定summary), risk(NORMAL/WARN/ALERT), trend(对象), anomalies(数组), suggestion(字符串), top_reasons(数组可选)
        """.trimIndent()
        val userPrompt = "请基于以下5分钟窗口数据做趋势总结，并给出风险等级与建议：\n${stats.toString()}"

        val payload = JSONObject()
        payload.put("model", model.trim())
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        messages.put(JSONObject().put("role", "user").put("content", userPrompt))
        payload.put("messages", messages)
        payload.put("temperature", 0.2)

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 20000
            doInput = true
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
        }
        conn.outputStream.use { os ->
            os.write(payload.toString().toByteArray(Charsets.UTF_8))
        }

        val code = conn.responseCode
        val body = runCatching {
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        }.getOrDefault("")
        if (body.isBlank()) throw IllegalStateException("Empty response($code)")

        val root = JSONObject(body)
        val content = root
            .optJSONArray("choices")
            ?.optJSONObject(0)
            ?.optJSONObject("message")
            ?.optString("content")
            .orEmpty()
            .trim()

        val obj = runCatching { JSONObject(content) }.getOrNull()
        if (obj != null) {
            if (!obj.has("type")) obj.put("type", "summary")
            if (!obj.has("provider")) obj.put("provider", "openai_compatible")
            if (!obj.has("from_ts_ms")) obj.put("from_ts_ms", start)
            if (!obj.has("to_ts_ms")) obj.put("to_ts_ms", end)
            if (!obj.has("count")) obj.put("count", window.size)
            return obj
        }

        val fallback = JSONObject()
        fallback.put("type", "summary")
        fallback.put("provider", "openai_compatible")
        fallback.put("from_ts_ms", start)
        fallback.put("to_ts_ms", end)
        fallback.put("count", window.size)
        fallback.put("raw", content.ifBlank { body })
        return fallback
    }

    private fun buildWindowStats(window: List<VitalSample>, start: Long, end: Long): JSONObject {
        val hrMin = window.minOf { it.hr }
        val hrMax = window.maxOf { it.hr }
        val hrAvg = window.map { it.hr }.average()
        val spo2Min = window.minOf { it.spo2 }
        val spo2Max = window.maxOf { it.spo2 }
        val tempMin = window.minOf { it.tempC }
        val tempMax = window.maxOf { it.tempC }

        val (risk, topReasons) = buildAggregatedRisk(window)

        val preview = JSONArray()
        downsample(window).take(20).forEach { s ->
            preview.put(
                JSONObject()
                    .put("ts_ms", s.tsMs)
                    .put("hr", s.hr)
                    .put("spo2", s.spo2)
                    .put("temp_c", s.tempC)
            )
        }

        val obj = JSONObject()
        obj.put("from_ts_ms", start)
        obj.put("to_ts_ms", end)
        obj.put("count", window.size)
        obj.put("hr_min", hrMin)
        obj.put("hr_max", hrMax)
        obj.put("hr_avg", hrAvg)
        obj.put("spo2_min", spo2Min)
        obj.put("spo2_max", spo2Max)
        obj.put("temp_min", tempMin)
        obj.put("temp_max", tempMax)
        obj.put("risk_hint", risk)
        val reasonsArr = JSONArray()
        topReasons.forEach { reasonsArr.put(it) }
        obj.put("top_reasons_hint", reasonsArr)
        obj.put("samples_preview", preview)
        return obj
    }

    private fun buildAggregatedRisk(window: List<VitalSample>): Pair<String, List<String>> {
        var overallRisk = 0
        val reasonCounts = HashMap<String, Int>()
        window.forEach { s ->
            val (risk, reasons) = evaluateRule(s)
            val r = when (risk) {
                "ALERT" -> 2
                "WARN" -> 1
                else -> 0
            }
            overallRisk = maxOf(overallRisk, r)
            reasons.forEach { reasonCounts[it] = (reasonCounts[it] ?: 0) + 1 }
        }
        val label = when (overallRisk) {
            2 -> "ALERT"
            1 -> "WARN"
            else -> "NORMAL"
        }
        val topReasons = reasonCounts.entries
            .sortedByDescending { it.value }
            .take(3)
            .map { it.key }
        return label to topReasons
    }

    private fun downsample(window: List<VitalSample>): List<VitalSample> {
        if (window.size <= 200) return window
        val step = (window.size / 200).coerceAtLeast(1)
        val out = ArrayList<VitalSample>(200)
        var i = 0
        while (i < window.size) {
            out.add(window[i])
            i += step
        }
        return out
    }

    private fun buildLocalSummary(window: List<VitalSample>, start: Long, end: Long, provider: String): JSONObject {
        var hrMin = Int.MAX_VALUE
        var hrMax = Int.MIN_VALUE
        var hrSum = 0
        var spo2Min = Int.MAX_VALUE
        var spo2Max = Int.MIN_VALUE
        var tempMin = Double.POSITIVE_INFINITY
        var tempMax = Double.NEGATIVE_INFINITY

        var overallRisk = 0
        val reasonCounts = HashMap<String, Int>()

        window.forEach { s ->
            hrMin = minOf(hrMin, s.hr)
            hrMax = maxOf(hrMax, s.hr)
            hrSum += s.hr
            spo2Min = minOf(spo2Min, s.spo2)
            spo2Max = maxOf(spo2Max, s.spo2)
            tempMin = minOf(tempMin, s.tempC)
            tempMax = maxOf(tempMax, s.tempC)
            val (risk, reasons) = evaluateRule(s)
            val r = when (risk) {
                "ALERT" -> 2
                "WARN" -> 1
                else -> 0
            }
            overallRisk = maxOf(overallRisk, r)
            reasons.forEach { reasonCounts[it] = (reasonCounts[it] ?: 0) + 1 }
        }

        val hrAvg = hrSum.toDouble() / window.size.toDouble()
        val label = when (overallRisk) {
            2 -> "ALERT"
            1 -> "WARN"
            else -> "NORMAL"
        }

        val topReasons = reasonCounts.entries
            .sortedByDescending { it.value }
            .take(3)
            .map { it.key }

        val suggestion = when (label) {
            "ALERT" -> "建议立即复测并联系家属/医生"
            "WARN" -> "建议休息后复测，关注趋势变化"
            else -> "指标整体平稳，继续观察"
        }

        val obj = JSONObject()
        obj.put("type", "summary")
        obj.put("provider", provider)
        obj.put("from_ts_ms", start)
        obj.put("to_ts_ms", end)
        obj.put("count", window.size)
        obj.put("risk", label)
        obj.put("hr_avg", hrAvg)
        obj.put("hr_min", hrMin)
        obj.put("hr_max", hrMax)
        obj.put("spo2_min", spo2Min)
        obj.put("spo2_max", spo2Max)
        obj.put("temp_min", tempMin)
        obj.put("temp_max", tempMax)
        val arr = JSONArray()
        topReasons.forEach { arr.put(it) }
        obj.put("top_reasons", arr)
        obj.put("suggestion", suggestion)
        return obj
    }

    private fun sendAi(type: String, json: String) {
        val i = Intent(BtActions.ACTION_AI).apply {
            setPackage(packageName)
            putExtra(BtActions.EXTRA_TYPE, type)
            putExtra(BtActions.EXTRA_TEXT, json)
            putExtra(BtActions.EXTRA_DEVICE_NAME, deviceName)
            putExtra(BtActions.EXTRA_DEVICE_ADDRESS, deviceAddress)
        }
        sendBroadcast(i)
    }

    private fun setState(newState: Int, name: String?, address: String?) {
        state.set(newState)
        val i = Intent(BtActions.ACTION_STATE).apply {
            setPackage(packageName)
            putExtra(BtActions.EXTRA_STATE, newState)
            putExtra(BtActions.EXTRA_DEVICE_NAME, name)
            putExtra(BtActions.EXTRA_DEVICE_ADDRESS, address)
        }
        sendBroadcast(i)
    }

    private fun sendRx(text: String) {
        val i = Intent(BtActions.ACTION_RX).apply {
            setPackage(packageName)
            putExtra(BtActions.EXTRA_TEXT, text)
            putExtra(BtActions.EXTRA_DEVICE_NAME, deviceName)
            putExtra(BtActions.EXTRA_DEVICE_ADDRESS, deviceAddress)
        }
        sendBroadcast(i)
    }

    private fun sendLog(text: String) {
        val i = Intent(BtActions.ACTION_LOG).apply {
            setPackage(packageName)
            putExtra(BtActions.EXTRA_TEXT, text)
        }
        sendBroadcast(i)
    }

    private fun closeSocket() {
        runCatching { inputStream?.close() }
        runCatching { outputStream?.close() }
        runCatching { socket?.close() }
        inputStream = null
        outputStream = null
        socket = null
    }

    private fun cancelReconnect(resetAttempts: Boolean) {
        reconnectGeneration.incrementAndGet()
        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = null
        if (resetAttempts) {
            reconnectAttempts = 0
        }
    }

    private fun maybeScheduleReconnect(delayMs: Long? = null) {
        if (manualDisconnect) return
        if (state.get() != BtState.DISCONNECTED) return

        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) return
        if (!hasConnectPermission()) return

        val addr = (deviceAddress ?: BtPrefs.getLastDeviceAddress(this)).orEmpty().trim()
        if (addr.isBlank()) return

        if (reconnectAttempts >= maxReconnectAttempts) {
            sendLog("自动重连已停止")
            return
        }
        reconnectAttempts += 1

        val backoffSec = (1 shl (reconnectAttempts - 1)).coerceAtMost(16)
        val d = delayMs ?: (backoffSec * 1000L)
        sendLog("自动重连(${reconnectAttempts}/$maxReconnectAttempts)：${d / 1000}s 后重试")

        val gen = reconnectGeneration.incrementAndGet()
        val r = Runnable {
            if (reconnectGeneration.get() != gen) return@Runnable
            if (manualDisconnect) return@Runnable
            if (state.get() != BtState.DISCONNECTED) return@Runnable
            val adapter = bluetoothAdapter ?: return@Runnable
            if (!adapter.isEnabled) return@Runnable
            connect(addr)
        }
        reconnectRunnable?.let { mainHandler.removeCallbacks(it) }
        reconnectRunnable = r
        mainHandler.postDelayed(r, d)
    }

    private fun hasConnectPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasScanPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
    }

    private fun getSafeDeviceName(device: BluetoothDevice): String? {
        return try {
            if (hasConnectPermission()) device.name else null
        } catch (_: SecurityException) {
            null
        }
    }

    private fun getSafeDeviceAddress(device: BluetoothDevice): String? {
        return try {
            if (hasConnectPermission()) device.address else null
        } catch (_: SecurityException) {
            null
        }
    }

    private fun getStringLabel(name: String): String {
        val id = resources.getIdentifier(name, "string", packageName)
        return if (id != 0) getString(id) else name
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(btStateReceiver) }
        cancelReconnect(resetAttempts = true)
        stopAiHealthAnalysis()
        runCatching { closeSocket() }
        ioExecutor.shutdownNow()
        analysisExecutor.shutdownNow()
    }
}

